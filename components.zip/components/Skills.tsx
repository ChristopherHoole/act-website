"use client";

export default function Skills() {
  return (
    <section className="section-padding bg-dark-darker">
      <div className="section-max-width">
        <div className="row">
          <div className="col-12 mb-5">
            <div className="d-flex align-items-center gap-2 mb-3">
              <div style={{ width: '24px', height: '1px', backgroundColor: '#2563eb' }}></div>
              <div className="font-monospace text-uppercase" style={{ fontSize: '11px', letterSpacing: '2.5px', color: '#2563eb' }}>
                Skills & Expertise
              </div>
            </div>
            <h2 className="fw-bold mb-4" style={{ fontSize: '42px', color: '#f8fafc', lineHeight: '1.1' }}>
              Deep Google Ads Expertise.<br />
              Custom AI Engineering.
            </h2>
          </div>

          <div className="col-12">
            <div className="row g-4">
              {/* Google Ads Expertise */}
              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                    Google Ads Mastery
                  </h3>
                  <ul className="list-unstyled mb-0">
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Search Campaigns
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Shopping Campaigns
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Performance Max
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Display Campaigns
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> YouTube Ads
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Smart Bidding (tCPA, tROAS)
                    </li>
                    <li className="font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Conversion Tracking
                    </li>
                  </ul>
                </div>
              </div>

              {/* Technical Skills */}
              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                    Technical Skills
                  </h3>
                  <ul className="list-unstyled mb-0">
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Python (AI/Automation)
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Google Ads API
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Google Ads Scripts
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Google Analytics 4
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> BigQuery & Data Studio
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Tag Manager
                    </li>
                    <li className="font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Machine Learning Models
                    </li>
                  </ul>
                </div>
              </div>

              {/* Analysis & Strategy */}
              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                    Analysis & Strategy
                  </h3>
                  <ul className="list-unstyled mb-0">
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Auction Dynamics
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Quality Score Optimization
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Competitive Analysis
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Attribution Modeling
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Funnel Optimization
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> LTV/CAC Analysis
                    </li>
                    <li className="font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> A/B Testing Frameworks
                    </li>
                  </ul>
                </div>
              </div>

              {/* Certifications */}
              <div className="col-md-6 col-lg-6">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#0f172a', border: '1px solid #2563eb' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                    Certifications
                  </h3>
                  <ul className="list-unstyled mb-0">
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#10b981' }}>✓</span> Google Ads Certified (Since 2009)
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#10b981' }}>✓</span> Google Analytics Certified
                    </li>
                    <li className="font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#10b981' }}>✓</span> Google Shopping Specialist
                    </li>
                  </ul>
                </div>
              </div>

              {/* Industry Experience */}
              <div className="col-md-6 col-lg-6">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#0f172a', border: '1px solid #1e293b' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    Industry Experience
                  </h3>
                  <ul className="list-unstyled mb-0">
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> E-commerce & Retail
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> SaaS & B2B Lead Gen
                    </li>
                    <li className="font-monospace mb-2" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Professional Services
                    </li>
                    <li className="font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                      <span style={{ color: '#2563eb' }}>→</span> Travel & Hospitality
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
