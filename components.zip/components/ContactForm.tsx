"use client";

import { useState } from "react";

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Invalid email format";
    }

    if (!formData.company.trim()) {
      newErrors.company = "Company is required";
    }

    if (!formData.message.trim()) {
      newErrors.message = "Message is required";
    } else if (formData.message.trim().length < 10) {
      newErrors.message = "Message must be at least 10 characters";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);

    // Console.log submission (no live API yet)
    console.log("Form submitted:", formData);

    // Simulate API delay
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      setFormData({ name: "", email: "", company: "", message: "" });

      // Reset success message after 5 seconds
      setTimeout(() => setSubmitSuccess(false), 5000);
    }, 1000);

    // TODO: Replace with actual API call when ready
    // const response = await fetch('/api/leads', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(formData),
    // });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    // Clear error when user starts typing
    if (errors[e.target.name]) {
      setErrors({
        ...errors,
        [e.target.name]: "",
      });
    }
  };

  return (
    <section id="contact" className="section-padding bg-dark-darker">
      <div className="section-max-width">
        <div className="row">
          <div className="col-12 mb-5">
            <div className="d-flex align-items-center gap-2 mb-3">
              <div style={{ width: '24px', height: '1px', backgroundColor: '#2563eb' }}></div>
              <div className="font-monospace text-uppercase" style={{ fontSize: '11px', letterSpacing: '2.5px', color: '#2563eb' }}>
                Get In Touch
              </div>
            </div>
            <h2 className="fw-bold mb-4" style={{ fontSize: '42px', color: '#f8fafc', lineHeight: '1.1' }}>
              Let&apos;s Discuss<br />
              Your Paid Ads
            </h2>
            <p className="font-monospace mb-0" style={{ fontSize: '16px', color: '#94a3b8', lineHeight: '1.7', maxWidth: '800px' }}>
              Currently accepting <span style={{ color: '#2563eb' }}>1 new client</span> and agency partnerships. Fill out the form below, and I&apos;ll respond within 24 hours.
            </p>
          </div>

          <div className="col-lg-8 mx-auto">
            <div className="p-5 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              {submitSuccess && (
                <div className="alert mb-4 p-3 rounded" style={{ backgroundColor: '#065f46', border: '1px solid #10b981', color: '#d1fae5' }}>
                  <div className="font-monospace" style={{ fontSize: '14px' }}>
                    ✓ Message sent successfully! I&apos;ll respond within 24 hours.
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label htmlFor="name" className="form-label font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                    Your Name *
                  </label>
                  <input
                    type="text"
                    className="form-control font-monospace"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    style={{
                      backgroundColor: '#0f172a',
                      border: errors.name ? '1px solid #ef4444' : '1px solid #334155',
                      color: '#f8fafc',
                      fontSize: '14px',
                      padding: '12px 16px',
                    }}
                    placeholder="John Smith"
                  />
                  {errors.name && (
                    <div className="font-monospace mt-2" style={{ fontSize: '12px', color: '#ef4444' }}>
                      {errors.name}
                    </div>
                  )}
                </div>

                <div className="mb-4">
                  <label htmlFor="email" className="form-label font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                    Email Address *
                  </label>
                  <input
                    type="email"
                    className="form-control font-monospace"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    style={{
                      backgroundColor: '#0f172a',
                      border: errors.email ? '1px solid #ef4444' : '1px solid #334155',
                      color: '#f8fafc',
                      fontSize: '14px',
                      padding: '12px 16px',
                    }}
                    placeholder="john@company.com"
                  />
                  {errors.email && (
                    <div className="font-monospace mt-2" style={{ fontSize: '12px', color: '#ef4444' }}>
                      {errors.email}
                    </div>
                  )}
                </div>

                <div className="mb-4">
                  <label htmlFor="company" className="form-label font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                    Company Name *
                  </label>
                  <input
                    type="text"
                    className="form-control font-monospace"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    style={{
                      backgroundColor: '#0f172a',
                      border: errors.company ? '1px solid #ef4444' : '1px solid #334155',
                      color: '#f8fafc',
                      fontSize: '14px',
                      padding: '12px 16px',
                    }}
                    placeholder="Acme Corp"
                  />
                  {errors.company && (
                    <div className="font-monospace mt-2" style={{ fontSize: '12px', color: '#ef4444' }}>
                      {errors.company}
                    </div>
                  )}
                </div>

                <div className="mb-4">
                  <label htmlFor="message" className="form-label font-monospace" style={{ fontSize: '13px', color: '#cbd5e1' }}>
                    Message *
                  </label>
                  <textarea
                    className="form-control font-monospace"
                    id="message"
                    name="message"
                    rows={6}
                    value={formData.message}
                    onChange={handleChange}
                    style={{
                      backgroundColor: '#0f172a',
                      border: errors.message ? '1px solid #ef4444' : '1px solid #334155',
                      color: '#f8fafc',
                      fontSize: '14px',
                      padding: '12px 16px',
                      resize: 'vertical',
                    }}
                    placeholder="Tell me about your business and Google Ads goals..."
                  ></textarea>
                  {errors.message && (
                    <div className="font-monospace mt-2" style={{ fontSize: '12px', color: '#ef4444' }}>
                      {errors.message}
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="btn font-monospace text-uppercase w-100"
                  style={{
                    backgroundColor: '#2563eb',
                    border: 'none',
                    color: '#ffffff',
                    fontSize: '13px',
                    letterSpacing: '2px',
                    padding: '14px',
                    fontWeight: 'bold',
                    opacity: isSubmitting ? 0.6 : 1,
                    cursor: isSubmitting ? 'not-allowed' : 'pointer',
                  }}
                >
                  {isSubmitting ? 'Sending...' : 'Send Message'}
                </button>
              </form>

              <div className="text-center mt-4 pt-4" style={{ borderTop: '1px solid #334155' }}>
                <p className="font-monospace mb-2" style={{ fontSize: '12px', color: '#64748b' }}>
                  Or email me directly:
                </p>
                <a
                  href="mailto:chrishoole101@gmail.com"
                  className="font-monospace"
                  style={{ fontSize: '14px', color: '#2563eb', textDecoration: 'none' }}
                >
                  chrishoole101@gmail.com
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
