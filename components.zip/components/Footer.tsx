"use client";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const navHeight = 56;
      const targetPosition = element.offsetTop - navHeight;
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth",
      });
    }
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <footer className="bg-dark-darker" style={{ borderTop: '1px solid #1e293b' }}>
      <div className="section-max-width py-5">
        <div className="row g-4">
          <div className="col-md-6 col-lg-4">
            <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
              Christopher Hoole
            </h3>
            <p className="font-monospace mb-3" style={{ fontSize: '13px', color: '#64748b', lineHeight: '1.6' }}>
              Google Ads specialist with 16 years experience and proprietary AI optimization engine.
            </p>
            <p className="font-monospace mb-0" style={{ fontSize: '12px', color: '#64748b' }}>
              Maximum 4 clients.<br />
              Currently accepting agency partnerships.
            </p>
          </div>

          <div className="col-md-6 col-lg-4">
            <h4 className="fw-bold mb-3" style={{ fontSize: '16px', color: '#f8fafc' }}>
              Quick Links
            </h4>
            <ul className="list-unstyled mb-0">
              <li className="mb-2">
                <button
                  onClick={() => scrollToSection("about")}
                  className="btn btn-link p-0 font-monospace text-start"
                  style={{ fontSize: '13px', color: '#64748b', textDecoration: 'none', border: 'none', background: 'none' }}
                >
                  → About Me
                </button>
              </li>
              <li className="mb-2">
                <button
                  onClick={() => scrollToSection("act")}
                  className="btn btn-link p-0 font-monospace text-start"
                  style={{ fontSize: '13px', color: '#64748b', textDecoration: 'none', border: 'none', background: 'none' }}
                >
                  → A.C.T Platform
                </button>
              </li>
              <li className="mb-2">
                <button
                  onClick={() => scrollToSection("work")}
                  className="btn btn-link p-0 font-monospace text-start"
                  style={{ fontSize: '13px', color: '#64748b', textDecoration: 'none', border: 'none', background: 'none' }}
                >
                  → Work History
                </button>
              </li>
              <li className="mb-2">
                <button
                  onClick={() => scrollToSection("faq")}
                  className="btn btn-link p-0 font-monospace text-start"
                  style={{ fontSize: '13px', color: '#64748b', textDecoration: 'none', border: 'none', background: 'none' }}
                >
                  → FAQ
                </button>
              </li>
              <li className="mb-2">
                <button
                  onClick={() => scrollToSection("contact")}
                  className="btn btn-link p-0 font-monospace text-start"
                  style={{ fontSize: '13px', color: '#64748b', textDecoration: 'none', border: 'none', background: 'none' }}
                >
                  → Contact
                </button>
              </li>
            </ul>
          </div>

          <div className="col-md-12 col-lg-4">
            <h4 className="fw-bold mb-3" style={{ fontSize: '16px', color: '#f8fafc' }}>
              Get In Touch
            </h4>
            <p className="font-monospace mb-3" style={{ fontSize: '13px', color: '#64748b', lineHeight: '1.6' }}>
              Email:{" "}
              <a
                href="mailto:chrishoole101@gmail.com"
                style={{ color: '#2563eb', textDecoration: 'none' }}
              >
                chrishoole101@gmail.com
              </a>
            </p>
            <button
              onClick={scrollToTop}
              className="btn font-monospace text-uppercase"
              style={{
                backgroundColor: 'transparent',
                border: '1px solid #334155',
                color: '#64748b',
                fontSize: '11px',
                letterSpacing: '1.5px',
                padding: '10px 20px',
              }}
            >
              ↑ Back to Top
            </button>
          </div>
        </div>
      </div>

      <div className="py-4" style={{ borderTop: '1px solid #1e293b' }}>
        <div className="section-max-width">
          <div className="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <p className="font-monospace mb-0" style={{ fontSize: '12px', color: '#475569' }}>
              © {new Date().getFullYear()} Christopher Hoole. All rights reserved.
            </p>
            <p className="font-monospace mb-0" style={{ fontSize: '11px', color: '#475569' }}>
              Powered by A.C.T (Ads Control Tower)
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
