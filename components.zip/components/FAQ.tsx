"use client";

export default function FAQ() {
  return (
    <section id="faq" className="section-padding bg-dark">
      <div className="section-max-width">
        <div className="row">
          <div className="col-12 mb-5">
            <div className="d-flex align-items-center gap-2 mb-3">
              <div style={{ width: '24px', height: '1px', backgroundColor: '#2563eb' }}></div>
              <div className="font-monospace text-uppercase" style={{ fontSize: '11px', letterSpacing: '2.5px', color: '#2563eb' }}>
                FAQ
              </div>
            </div>
            <h2 className="fw-bold mb-4" style={{ fontSize: '42px', color: '#f8fafc', lineHeight: '1.1' }}>
              Frequently Asked<br />
              Questions
            </h2>
          </div>

          <div className="col-lg-10 mx-auto">
            <div className="mb-4 p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                How much do you charge?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                My fee is a percentage of ad spend (typically 15-20% depending on account size and complexity). There&apos;s a minimum monthly retainer of £2,500. I don&apos;t do performance-based pricing because it creates misaligned incentives—I optimize for your profitability, not my commission.
              </p>
            </div>

            <div className="mb-4 p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                What&apos;s the minimum ad spend you work with?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                £15,000/month minimum. Below that threshold, Google Ads doesn&apos;t generate enough data for A.C.T to be effective, and my fee wouldn&apos;t be justified. If you&apos;re below £15k/month, I can recommend other excellent managers who specialize in smaller accounts.
              </p>
            </div>

            <div className="mb-4 p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                Do you require long-term contracts?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                No. I work month-to-month with a 30-day cancellation notice. If you&apos;re not seeing results or you&apos;re unhappy with the service, you can walk away. I earn your business every month.
              </p>
            </div>

            <div className="mb-4 p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                How quickly will I see results?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                Quick wins typically appear within the first 2-4 weeks (removing wasteful spend, fixing obvious issues). Meaningful performance improvements usually take 60-90 days as A.C.T learns your account patterns and builds optimization momentum. Google Ads isn&apos;t a &quot;flip a switch&quot; platform—sustainable results require data and testing.
              </p>
            </div>

            <div className="mb-4 p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                What industries do you work with?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                E-commerce, SaaS/B2B lead generation, professional services, and travel/hospitality. I avoid highly regulated industries (finance, healthcare, legal) and anything that violates Google&apos;s advertising policies.
              </p>
            </div>

            <div className="mb-4 p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                Do you work with agencies?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                Yes. I offer white-label partnerships where I manage Google Ads for your clients under your agency&apos;s branding. Your clients never know I exist—you get the credit, I do the work. Minimum 2-client commitment for agency partnerships.
              </p>
            </div>

            <div className="mb-4 p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                Will you take over an existing account or only start from scratch?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                I prefer taking over existing accounts—there&apos;s historical data to learn from. I&apos;ll audit your current setup, identify what&apos;s working (and keep it), and fix what&apos;s broken. Starting from scratch is fine too, but expect a longer learning period.
              </p>
            </div>

            <div className="mb-4 p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                What happens to A.C.T if I stop working with you?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                A.C.T is my proprietary platform—it doesn&apos;t transfer. However, your Google Ads account remains yours with all campaigns, data, and settings intact. You&apos;ll lose the AI monitoring and optimization engine, but your account continues running as a standard Google Ads account.
              </p>
            </div>

            <div className="p-4 rounded" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#2563eb' }}>
                How do I get started?
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                Book a discovery call using the contact form below. We&apos;ll discuss your business, current ad performance, and goals. If we&apos;re a good fit, I&apos;ll audit your account (free) and send you a proposal. No pressure, no sales tactics.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
