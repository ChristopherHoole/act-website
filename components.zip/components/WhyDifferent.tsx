"use client";

export default function WhyDifferent() {
  return (
    <section className="section-padding bg-dark-darker">
      <div className="section-max-width">
        <div className="row">
          <div className="col-12 mb-5">
            <div className="d-flex align-items-center gap-2 mb-3">
              <div style={{ width: '24px', height: '1px', backgroundColor: '#2563eb' }}></div>
              <div className="font-monospace text-uppercase" style={{ fontSize: '11px', letterSpacing: '2.5px', color: '#2563eb' }}>
                Why Different
              </div>
            </div>
            <h2 className="fw-bold mb-4" style={{ fontSize: '42px', color: '#f8fafc', lineHeight: '1.1' }}>
              What Sets Me Apart<br />
              From Other Google Ads Managers
            </h2>
          </div>

          <div className="col-12">
            <div className="row g-4 mb-5">
              <div className="col-md-6">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #2563eb' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '20px', color: '#2563eb' }}>
                    I Built My Own AI Engine
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                    Most managers use the same tools (Google Ads interface, basic scripts, third-party platforms). I built A.C.T from scratch—a custom AI engine that analyzes your account with strategies no competitor can replicate. This isn&apos;t a white-label solution; it&apos;s proprietary technology that took years to develop.
                  </p>
                </div>
              </div>

              <div className="col-md-6">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #2563eb' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '20px', color: '#2563eb' }}>
                    Maximum 4 Clients
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#cbd5e1', lineHeight: '1.6' }}>
                    I intentionally limit my client roster to 4 accounts. This isn&apos;t a scalability play—it&apos;s a quality guarantee. You&apos;re not one of 50 accounts managed by a junior team member. You get my direct attention, my strategic thinking, and my 16 years of expertise applied exclusively to your business.
                  </p>
                </div>
              </div>

              <div className="col-md-6">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    No Junior Teams
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#94a3b8', lineHeight: '1.6' }}>
                    You work directly with me—no account managers, no handoffs, no junior staff learning on your budget. Every decision, every optimization, every strategic call comes from someone with 16 years of experience managing £50M+ in ad spend.
                  </p>
                </div>
              </div>

              <div className="col-md-6">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    24/7 AI Monitoring
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#94a3b8', lineHeight: '1.6' }}>
                    Traditional managers check campaigns weekly (maybe daily if you&apos;re lucky). A.C.T monitors your account every hour, catching budget drains, performance drops, and opportunities before they show up in weekly reports. It never sleeps.
                  </p>
                </div>
              </div>

              <div className="col-md-6">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    Predictive, Not Reactive
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#94a3b8', lineHeight: '1.6' }}>
                    Most managers react to problems after they happen. A.C.T predicts performance trends and recommends changes before issues appear. You stay ahead of the curve instead of constantly playing catch-up.
                  </p>
                </div>
              </div>

              <div className="col-md-6">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    Complete Transparency
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '14px', color: '#94a3b8', lineHeight: '1.6' }}>
                    Every change is logged and explained. You see exactly what A.C.T recommends, why I approved it, and the expected impact. No black boxes, no vague &quot;trust the algorithm&quot; messaging. You understand every decision.
                  </p>
                </div>
              </div>
            </div>

            <div className="text-center p-5 rounded" style={{ backgroundColor: '#0f172a', border: '1px solid #2563eb' }}>
              <h3 className="fw-bold mb-3" style={{ fontSize: '24px', color: '#2563eb' }}>
                The Bottom Line
              </h3>
              <p className="font-monospace mb-0" style={{ fontSize: '16px', color: '#cbd5e1', lineHeight: '1.7', maxWidth: '900px', margin: '0 auto' }}>
                You&apos;re not hiring a generalist who manages 50 accounts with cookie-cutter strategies. You&apos;re getting a senior specialist with proprietary AI technology, limited availability, and a proven track record managing £50M+ in ad spend. That&apos;s the difference.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
