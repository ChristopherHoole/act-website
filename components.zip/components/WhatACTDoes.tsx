"use client";

export default function WhatACTDoes() {
  return (
    <section id="act" className="section-padding bg-dark">
      <div className="section-max-width">
        <div className="row">
          <div className="col-12 mb-5">
            <div className="d-flex align-items-center gap-2 mb-3">
              <div style={{ width: '24px', height: '1px', backgroundColor: '#2563eb' }}></div>
              <div className="font-monospace text-uppercase" style={{ fontSize: '11px', letterSpacing: '2.5px', color: '#2563eb' }}>
                A.C.T Platform
              </div>
            </div>
            <h2 className="fw-bold mb-4" style={{ fontSize: '42px', color: '#f8fafc', lineHeight: '1.1' }}>
              What A.C.T Does:<br />
              AI-Powered Campaign Control
            </h2>
            <p className="font-monospace mb-0" style={{ fontSize: '16px', color: '#94a3b8', lineHeight: '1.7', maxWidth: '800px' }}>
              A.C.T (Ads Control Tower) is my proprietary AI engine that monitors, analyzes, and optimizes your Google Ads campaigns 24/7. It doesn&apos;t just automate tasks—it thinks ahead.
            </p>
          </div>

          <div className="col-12">
            <div className="row g-4">
              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <div className="mb-3" style={{ fontSize: '32px' }}>🔍</div>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    24/7 Performance Monitoring
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '13px', color: '#94a3b8', lineHeight: '1.6' }}>
                    A.C.T checks your campaigns every hour, analyzing thousands of data points to detect issues before they drain your budget.
                  </p>
                </div>
              </div>

              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <div className="mb-3" style={{ fontSize: '32px' }}>🎯</div>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    Predictive Optimization
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '13px', color: '#94a3b8', lineHeight: '1.6' }}>
                    Machine learning models forecast performance trends and recommend adjustments before problems appear in your reports.
                  </p>
                </div>
              </div>

              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <div className="mb-3" style={{ fontSize: '32px' }}>💰</div>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    Budget Protection
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '13px', color: '#94a3b8', lineHeight: '1.6' }}>
                    Automatic alerts when campaigns exceed CPA targets or when spend velocity suggests budget will exhaust prematurely.
                  </p>
                </div>
              </div>

              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <div className="mb-3" style={{ fontSize: '32px' }}>📊</div>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    Deep Pattern Recognition
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '13px', color: '#94a3b8', lineHeight: '1.6' }}>
                    Identifies hidden correlations across device types, times, audiences, and keywords that humans would miss.
                  </p>
                </div>
              </div>

              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <div className="mb-3" style={{ fontSize: '32px' }}>⚡</div>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    Automated Bid Adjustments
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '13px', color: '#94a3b8', lineHeight: '1.6' }}>
                    Dynamic bid modifications based on conversion probability, competitive pressure, and budget pacing—updated hourly.
                  </p>
                </div>
              </div>

              <div className="col-md-6 col-lg-4">
                <div className="p-4 rounded h-100" style={{ backgroundColor: '#1e293b', border: '1px solid #334155' }}>
                  <div className="mb-3" style={{ fontSize: '32px' }}>🔔</div>
                  <h3 className="fw-bold mb-3" style={{ fontSize: '18px', color: '#f8fafc' }}>
                    Smart Alerts
                  </h3>
                  <p className="font-monospace mb-0" style={{ fontSize: '13px', color: '#94a3b8', lineHeight: '1.6' }}>
                    Only get notified when it matters—A.C.T filters out noise and alerts you to genuine anomalies requiring attention.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-5 p-4 rounded text-center" style={{ backgroundColor: '#0f172a', border: '1px solid #2563eb' }}>
              <p className="font-monospace mb-0" style={{ fontSize: '16px', color: '#cbd5e1', lineHeight: '1.7' }}>
                <span style={{ color: '#2563eb' }}>The result:</span> Campaigns that adapt in real-time to market conditions, protect your budget from waste, and scale profitably without constant manual oversight.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
